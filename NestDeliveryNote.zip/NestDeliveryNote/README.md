# Nest Delivery Note

An Android app for construction site staff to photograph delivery notes, extract
the data with on-device OCR, review/correct it, save it per-user in Firebase, and
receive a daily Excel report by email — sent server-side so it goes out even if
the phone is off.

See **[docs/SETUP.md](docs/SETUP.md)** for the required Firebase project setup,
Google OAuth configuration, secrets, and the full APK build process — start there.

## Status

This is a complete first-version implementation of every item in the priority
list (Google Sign-In, camera/gallery capture, OCR, review/edit form, multiple
material rows, duplicate detection, Firestore/Storage integration, XLSX report
generation, scheduled email delivery, debug APK build, GitHub Actions CI). It has
not been run against a live Firebase project or real delivery-note photos —
see the last section of `docs/SETUP.md` for exactly what still needs real
credentials/hardware to verify.
