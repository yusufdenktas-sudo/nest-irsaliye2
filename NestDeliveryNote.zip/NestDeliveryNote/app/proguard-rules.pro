# ML Kit
-keep class com.google.mlkit.** { *; }
# Firestore model classes (data classes used with toObject)
-keepclassmembers class com.nest.deliverynote.data.model.** {
  *;
}
