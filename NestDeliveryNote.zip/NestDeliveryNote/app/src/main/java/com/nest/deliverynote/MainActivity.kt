package com.nest.deliverynote

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nest.deliverynote.auth.GoogleAuthManager
import com.nest.deliverynote.data.model.DeliveryNote
import com.nest.deliverynote.data.model.MaterialLine
import com.nest.deliverynote.data.model.ReportSettings
import com.nest.deliverynote.data.repository.DeliveryNoteRepository
import com.nest.deliverynote.data.repository.SaveOutcome
import com.nest.deliverynote.data.remote.FirestoreRepository
import com.nest.deliverynote.data.remote.StorageRepository
import com.nest.deliverynote.ocr.DeliveryNoteParserRegistry
import com.nest.deliverynote.ocr.OcrProcessor
import com.nest.deliverynote.ui.components.DuplicateWarningDialog
import com.nest.deliverynote.ui.navigation.Routes
import com.nest.deliverynote.ui.screens.*
import com.nest.deliverynote.ui.theme.NestDeliveryNoteTheme
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {

    private lateinit var authManager: GoogleAuthManager
    private lateinit var repository: DeliveryNoteRepository
    private val ocrProcessor = OcrProcessor()
    private val firestoreRepo = FirestoreRepository()
    private val storageRepo = StorageRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        authManager = GoogleAuthManager(this)
        repository = DeliveryNoteRepository(this)

        setContent {
            NestDeliveryNoteTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    NestApp(authManager, repository, firestoreRepo, storageRepo, ocrProcessor)
                }
            }
        }
    }
}

@Composable
fun NestApp(
    authManager: GoogleAuthManager,
    repository: DeliveryNoteRepository,
    firestoreRepo: FirestoreRepository,
    storageRepo: StorageRepository,
    ocrProcessor: OcrProcessor
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()

    var currentUser by remember { mutableStateOf(authManager.currentUser) }
    var authError by remember { mutableStateOf<String?>(null) }

    val pendingDraftCount by produceState(initialValue = 0, currentUser) {
        val uid = currentUser?.uid
        if (uid == null) {
            value = 0
        } else {
            repository.observePendingDrafts(uid).collect { value = it.size }
        }
    }

    var pendingPhotoUri by remember { mutableStateOf<Uri?>(null) } // camera capture target
    var scanImageUri by remember { mutableStateOf<Uri?>(null) }
    var isProcessingOcr by remember { mutableStateOf(false) }
    var ocrError by remember { mutableStateOf<String?>(null) }

    var reviewState by remember { mutableStateOf<ReviewFormState?>(null) }
    var isSaving by remember { mutableStateOf(false) }
    var saveError by remember { mutableStateOf<String?>(null) }
    var duplicateCandidate by remember { mutableStateOf<DeliveryNote?>(null) }
    var pendingSaveForDuplicateOverride by remember { mutableStateOf<ReviewFormState?>(null) }

    var records by remember { mutableStateOf<List<DeliveryNote>>(emptyList()) }
    var recordsLoading by remember { mutableStateOf(false) }
    var selectedRecord by remember { mutableStateOf<DeliveryNote?>(null) }
    var selectedRecordPhotoUrl by remember { mutableStateOf<String?>(null) }

    var reportSettings by remember { mutableStateOf(ReportSettings()) }
    var isSavingSettings by remember { mutableStateOf(false) }
    var settingsSavedMessage by remember { mutableStateOf<String?>(null) }

    val signInLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        scope.launch {
            val outcome = authManager.handleSignInResult(result.data)
            outcome.onSuccess {
                currentUser = it
                authError = null
                navController.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } }
            }.onFailure {
                authError = it.message ?: "Sign-in failed"
            }
        }
    }

    val takePictureLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            scanImageUri = pendingPhotoUri
        }
    }

    val pickImageLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) scanImageUri = uri }

    val cameraPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val uri = createCaptureUri(context)
            pendingPhotoUri = uri
            takePictureLauncher.launch(uri)
        } else {
            ocrError = "Camera permission is required to take a photo."
        }
    }

    fun startCameraCapture() {
        val hasPermission = androidx.core.content.ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.CAMERA
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (hasPermission) {
            val uri = createCaptureUri(context)
            pendingPhotoUri = uri
            takePictureLauncher.launch(uri)
        } else {
            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    fun runOcr() {
        val uid = currentUser?.uid ?: return
        val uri = scanImageUri ?: return
        isProcessingOcr = true
        ocrError = null
        scope.launch {
            try {
                val bitmap = context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)
                } ?: throw IllegalStateException("Could not read the selected image.")

                val result = ocrProcessor.process(bitmap)
                val parsed = DeliveryNoteParserRegistry.parse(result.rawText, result.qrPayload)

                reviewState = ReviewFormState(
                    supplierCompany = parsed.supplierCompany ?: "",
                    deliveryNoteNumber = parsed.deliveryNoteNumber ?: "",
                    deliveryNoteDate = parsed.deliveryNoteDate ?: "",
                    receivingCompany = parsed.receivingCompany ?: "",
                    siteArea = parsed.siteArea ?: "",
                    vehiclePlate = parsed.vehiclePlate ?: "",
                    materials = (if (parsed.materials.isEmpty()) mutableListOf(MaterialLine()) else parsed.materials)
                )
                navController.navigate(Routes.REVIEW)
            } catch (e: Exception) {
                ocrError = e.message ?: "Could not read this image. Please try again or enter data manually."
            } finally {
                isProcessingOcr = false
            }
        }
    }

    fun buildNoteFromForm(form: ReviewFormState): DeliveryNote {
        val uid = currentUser?.uid ?: ""
        return DeliveryNote(
            ownerUid = uid,
            supplierCompany = form.supplierCompany.trim(),
            deliveryNoteNumber = form.deliveryNoteNumber.trim(),
            deliveryNoteDate = form.deliveryNoteDate.trim(),
            receivingCompany = form.receivingCompany.trim(),
            siteArea = form.siteArea.trim(),
            vehiclePlate = form.vehiclePlate.trim(),
            materials = form.materials.filter { it.name.isNotBlank() || it.quantity > 0 }
        )
    }

    fun performSave(form: ReviewFormState, allowDuplicate: Boolean) {
        val uid = currentUser?.uid ?: return
        val errors = com.nest.deliverynote.utils.Validators.validateForSave(
            supplierCompany = form.supplierCompany,
            deliveryNoteNumber = form.deliveryNoteNumber,
            deliveryNoteDate = form.deliveryNoteDate,
            receivingCompany = form.receivingCompany,
            materials = form.materials.map { it.quantity to it.unit }
        )
        if (errors.isNotEmpty()) {
            saveError = errors.joinToString("\n")
            return
        }

        isSaving = true
        saveError = null
        scope.launch {
            val note = buildNoteFromForm(form)
            when (val outcome = repository.save(uid, note, scanImageUri, allowDuplicate)) {
                is SaveOutcome.Saved -> {
                    isSaving = false
                    scanImageUri = null
                    reviewState = null
                    navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } }
                }
                is SaveOutcome.SavedAsPendingDraft -> {
                    isSaving = false
                    scanImageUri = null
                    reviewState = null
                    saveError = null
                    navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } }
                }
                is SaveOutcome.DuplicateDetected -> {
                    isSaving = false
                    duplicateCandidate = outcome.existing
                    pendingSaveForDuplicateOverride = form
                }
                is SaveOutcome.Failed -> {
                    isSaving = false
                    saveError = outcome.message
                }
            }
        }
    }

    fun loadRecords() {
        val uid = currentUser?.uid ?: return
        recordsLoading = true
        scope.launch {
            records = try {
                repository.listSavedNotes(uid)
            } catch (e: Exception) {
                emptyList()
            }
            recordsLoading = false
        }
    }

    fun loadSettings() {
        val uid = currentUser?.uid ?: return
        scope.launch {
            reportSettings = try {
                firestoreRepo.getReportSettings(uid)
            } catch (e: Exception) {
                ReportSettings()
            }
        }
    }

    NavHost(navController = navController, startDestination = if (currentUser != null) Routes.HOME else Routes.LOGIN) {
        composable(Routes.LOGIN) {
            LoginScreen(
                onSignInClick = { signInLauncher.launch(authManager.getSignInIntent()) },
                errorMessage = authError
            )
        }
        composable(Routes.HOME) {
            HomeScreen(
                user = currentUser,
                pendingDraftCount = pendingDraftCount,
                onScanClick = {
                    scanImageUri = null
                    ocrError = null
                    navController.navigate(Routes.SCAN)
                },
                onRecordsClick = {
                    loadRecords()
                    navController.navigate(Routes.RECORDS)
                },
                onSettingsClick = {
                    loadSettings()
                    navController.navigate(Routes.SETTINGS)
                },
                onSignOutClick = {
                    authManager.signOut()
                    currentUser = null
                    navController.navigate(Routes.LOGIN) { popUpTo(0) }
                }
            )
        }
        composable(Routes.SCAN) {
            ScanScreen(
                imageUri = scanImageUri,
                isProcessing = isProcessingOcr,
                errorMessage = ocrError,
                onTakePhoto = { startCameraCapture() },
                onPickGallery = { pickImageLauncher.launch("image/*") },
                onProcess = { runOcr() },
                onBack = { scanImageUri = null }
            )
        }
        composable(Routes.REVIEW) {
            val state = reviewState
            if (state != null) {
                ReviewScreen(
                    initial = state,
                    isSaving = isSaving,
                    errorMessage = saveError,
                    onSave = { form -> performSave(form, allowDuplicate = false) },
                    onCancel = { navController.popBackStack() }
                )
            }
            duplicateCandidate?.let { existing ->
                DuplicateWarningDialog(
                    onSaveAnyway = {
                        val form = pendingSaveForDuplicateOverride
                        duplicateCandidate = null
                        if (form != null) performSave(form, allowDuplicate = true)
                    },
                    onDismiss = { duplicateCandidate = null }
                )
            }
        }
        composable(Routes.RECORDS) {
            RecordsListScreen(
                records = records,
                isLoading = recordsLoading,
                onBack = { navController.popBackStack() },
                onOpenRecord = { note ->
                    selectedRecord = note
                    selectedRecordPhotoUrl = null
                    scope.launch {
                        if (note.photoStoragePath.isNotBlank()) {
                            selectedRecordPhotoUrl = try {
                                storageRepo.getSignedUrl(note.photoStoragePath).toString()
                            } catch (e: Exception) { null }
                        }
                    }
                    navController.navigate(Routes.RECORD_DETAIL.replace("{noteId}", note.id))
                }
            )
        }
        composable(Routes.RECORD_DETAIL) {
            val note = selectedRecord
            if (note != null) {
                RecordDetailScreen(
                    note = note,
                    photoUrl = selectedRecordPhotoUrl,
                    onBack = { navController.popBackStack() },
                    onDeleteRequested = {
                        val uid = currentUser?.uid
                        if (uid != null) {
                            scope.launch {
                                repository.deleteNote(uid, note)
                                navController.popBackStack()
                                loadRecords()
                            }
                        }
                    }
                )
            }
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                initial = reportSettings,
                isSaving = isSavingSettings,
                savedMessage = settingsSavedMessage,
                onBack = { navController.popBackStack() },
                onSave = { settings ->
                    val uid = currentUser?.uid
                    if (uid != null) {
                        isSavingSettings = true
                        settingsSavedMessage = null
                        scope.launch {
                            try {
                                firestoreRepo.saveReportSettings(uid, settings)
                                reportSettings = settings
                                settingsSavedMessage = "Saved."
                            } catch (e: Exception) {
                                settingsSavedMessage = "Could not save: ${e.message}"
                            }
                            isSavingSettings = false
                        }
                    }
                }
            )
        }
    }
}

private fun createCaptureUri(context: android.content.Context): Uri {
    val dir = File(context.cacheDir, "delivery_note_photos").apply { mkdirs() }
    val file = File(dir, "capture_${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
}
