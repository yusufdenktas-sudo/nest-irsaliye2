package com.nest.deliverynote

import android.app.Application
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.nest.deliverynote.sync.SyncWorker
import java.util.concurrent.TimeUnit

class NestApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        schedulePendingDraftSync()
    }

    /**
     * WorkManager itself re-evaluates the NetworkType.CONNECTED constraint whenever
     * connectivity changes, so this single periodic request also covers "upload
     * automatically when the connection returns" without a separate BroadcastReceiver.
     * 15 minutes is WorkManager's minimum periodic interval.
     */
    private fun schedulePendingDraftSync() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "pending_draft_sync",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
