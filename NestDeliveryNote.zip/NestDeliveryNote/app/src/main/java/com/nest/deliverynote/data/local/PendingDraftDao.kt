package com.nest.deliverynote.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PendingDraftDao {
    @Insert
    suspend fun insert(draft: PendingDraftEntity): Long

    @Update
    suspend fun update(draft: PendingDraftEntity)

    @Delete
    suspend fun delete(draft: PendingDraftEntity)

    @Query("SELECT * FROM pending_drafts WHERE ownerUid = :ownerUid ORDER BY createdAtEpochMs DESC")
    fun observeForUser(ownerUid: String): Flow<List<PendingDraftEntity>>

    @Query("SELECT * FROM pending_drafts ORDER BY createdAtEpochMs ASC")
    suspend fun getAllPending(): List<PendingDraftEntity>

    @Query("SELECT COUNT(*) FROM pending_drafts WHERE ownerUid = :ownerUid")
    suspend fun countForUser(ownerUid: String): Int
}
