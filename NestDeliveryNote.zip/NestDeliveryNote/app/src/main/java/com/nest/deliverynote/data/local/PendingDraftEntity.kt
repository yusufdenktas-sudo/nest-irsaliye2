package com.nest.deliverynote.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A delivery note that was captured while offline (or while a save attempt failed).
 * [payloadJson] holds the serialized DeliveryNote; [localPhotoPath] points at the
 * photo file cached in app-private storage until it is uploaded to Firebase Storage.
 */
@Entity(tableName = "pending_drafts")
data class PendingDraftEntity(
    @PrimaryKey(autoGenerate = true)
    val localId: Long = 0,
    val ownerUid: String,
    val payloadJson: String,
    val localPhotoPath: String,
    val createdAtEpochMs: Long,
    val uploadAttempts: Int = 0,
    val lastError: String? = null
)
