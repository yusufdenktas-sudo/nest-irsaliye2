package com.nest.deliverynote.data.model

import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

/**
 * One scanned delivery note. A single physical delivery note can contain multiple
 * materials — each is stored as a [MaterialLine] so the Excel export can emit one
 * row per material while still referencing the same source document.
 */
data class DeliveryNote(
    var id: String = "",
    @get:PropertyName("ownerUid") @set:PropertyName("ownerUid")
    var ownerUid: String = "",
    var supplierCompany: String = "",
    var deliveryNoteNumber: String = "",
    var deliveryNoteDate: String = "", // stored as ISO-8601 (yyyy-MM-dd), user-editable
    var receivingCompany: String = "",
    var siteArea: String = "",
    var vehiclePlate: String = "",
    var materials: List<MaterialLine> = emptyList(),
    var photoStoragePath: String = "", // Firebase Storage path, NOT a public URL
    var rawOcrText: String = "",
    var scannedQrPayload: String? = null,
    var duplicateOfId: String? = null,
    var status: RecordStatus = RecordStatus.PENDING_UPLOAD,
    @ServerTimestamp
    var createdAt: Date? = null,
    @ServerTimestamp
    var updatedAt: Date? = null,
    var reportedAt: Date? = null,
    var reportBatchId: String? = null
) {
    fun dedupeKey(): String =
        "${supplierCompany.trim().lowercase()}|${deliveryNoteNumber.trim().lowercase()}"
}

data class MaterialLine(
    var name: String = "",
    var quantity: Double = 0.0,
    var unit: String = "" // m3, m2, lm, pcs, ton, etc.
)

enum class RecordStatus {
    PENDING_UPLOAD,   // saved locally only, no network yet
    UPLOADING,
    SAVED,            // confirmed written to Firestore
    REPORTED,         // included in a successfully-sent Excel report
    REPORT_FAILED,    // included in a report attempt that failed / was uncertain
    DELETED
}
