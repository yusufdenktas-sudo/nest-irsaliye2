package com.nest.deliverynote.data.model

/** Per-user report configuration, stored at users/{uid}/settings/report in Firestore. */
data class ReportSettings(
    var recipientEmail: String = "yusufdenktas@nestpeyzaj.com",
    var sendHour: Int = 0,       // 0-23, Europe/Istanbul local time
    var sendMinute: Int = 0,     // 0-59
    var timezone: String = "Europe/Istanbul"
)
