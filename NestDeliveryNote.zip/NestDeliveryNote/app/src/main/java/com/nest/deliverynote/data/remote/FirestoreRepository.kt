package com.nest.deliverynote.data.remote

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import com.nest.deliverynote.data.model.DeliveryNote
import com.nest.deliverynote.data.model.ReportSettings
import kotlinx.coroutines.tasks.await

/**
 * All records live under users/{uid}/deliveryNotes/{noteId} so that Firestore
 * security rules can enforce "users can only access their own records" with a
 * single simple rule (see firestore.rules).
 */
class FirestoreRepository {

    private val db = FirebaseFirestore.getInstance()

    private fun notesCollection(uid: String) =
        db.collection("users").document(uid).collection("deliveryNotes")

    suspend fun findByDedupeKey(uid: String, supplier: String, noteNumber: String): DeliveryNote? {
        val snapshot = notesCollection(uid)
            .whereEqualTo("supplierCompany", supplier)
            .whereEqualTo("deliveryNoteNumber", noteNumber)
            .limit(5)
            .get(Source.SERVER)
            .await()
        return snapshot.documents.firstOrNull()?.toObject(DeliveryNote::class.java)
    }

    /** Returns the generated document ID. Throws on failure — callers must not fake success. */
    suspend fun saveNote(uid: String, note: DeliveryNote): String {
        val docRef = if (note.id.isBlank()) {
            notesCollection(uid).document()
        } else {
            notesCollection(uid).document(note.id)
        }
        note.id = docRef.id
        note.ownerUid = uid
        docRef.set(note).await() // throws if it fails — caller shows real error, not fake success
        return docRef.id
    }

    suspend fun deleteNote(uid: String, noteId: String) {
        notesCollection(uid).document(noteId).delete().await()
    }

    suspend fun getNote(uid: String, noteId: String): DeliveryNote? =
        notesCollection(uid).document(noteId).get().await().toObject(DeliveryNote::class.java)

    suspend fun listNotes(uid: String, limit: Long = 100): List<DeliveryNote> =
        notesCollection(uid)
            .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(limit)
            .get()
            .await()
            .documents
            .mapNotNull { it.toObject(DeliveryNote::class.java) }

    suspend fun getReportSettings(uid: String): ReportSettings {
        val doc = db.collection("users").document(uid)
            .collection("settings").document("report")
            .get().await()
        return doc.toObject(ReportSettings::class.java) ?: ReportSettings()
    }

    suspend fun saveReportSettings(uid: String, settings: ReportSettings) {
        db.collection("users").document(uid)
            .collection("settings").document("report")
            .set(settings)
            .await()
    }
}
