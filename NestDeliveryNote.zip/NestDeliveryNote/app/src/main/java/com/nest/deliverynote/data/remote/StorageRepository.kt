package com.nest.deliverynote.data.remote

import android.net.Uri
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import java.util.UUID

/**
 * Delivery note photos are stored under photos/{uid}/{noteId}.jpg. There is no
 * "make public" step anywhere in this app — access is only via authenticated
 * Storage SDK calls, gated by storage.rules (owner-only reads/writes).
 */
class StorageRepository {

    private val storage = FirebaseStorage.getInstance()

    suspend fun uploadPhoto(uid: String, localFileUri: Uri, noteId: String = UUID.randomUUID().toString()): String {
        val path = "photos/$uid/$noteId.jpg"
        val ref = storage.reference.child(path)
        ref.putFile(localFileUri).await() // throws on failure; no fake success
        return path // store the storage PATH, not a downloadable URL
    }

    suspend fun deletePhoto(storagePath: String) {
        if (storagePath.isBlank()) return
        storage.reference.child(storagePath).delete().await()
    }

    /** Generates a short-lived signed download URL, only ever called for the owner's own record. */
    suspend fun getSignedUrl(storagePath: String): Uri =
        storage.reference.child(storagePath).downloadUrl.await()
}
