package com.nest.deliverynote.data.repository

import com.nest.deliverynote.data.model.DeliveryNote
import com.nest.deliverynote.data.model.MaterialLine
import org.json.JSONArray
import org.json.JSONObject

/**
 * Manual, dependency-free JSON (de)serialization for [DeliveryNote], used only to
 * persist pending offline drafts in Room as a single TEXT column. Uses org.json,
 * which ships with Android — no extra library required.
 */
object DeliveryNoteJson {

    fun toJson(note: DeliveryNote): JSONObject = JSONObject().apply {
        put("id", note.id)
        put("ownerUid", note.ownerUid)
        put("supplierCompany", note.supplierCompany)
        put("deliveryNoteNumber", note.deliveryNoteNumber)
        put("deliveryNoteDate", note.deliveryNoteDate)
        put("receivingCompany", note.receivingCompany)
        put("siteArea", note.siteArea)
        put("vehiclePlate", note.vehiclePlate)
        put("rawOcrText", note.rawOcrText)
        put("scannedQrPayload", note.scannedQrPayload)
        put("materials", JSONArray().apply {
            note.materials.forEach { m ->
                put(JSONObject().apply {
                    put("name", m.name)
                    put("quantity", m.quantity)
                    put("unit", m.unit)
                })
            }
        })
    }

    fun fromJson(json: String): DeliveryNote {
        val obj = JSONObject(json)
        val materials = mutableListOf<MaterialLine>()
        val arr = obj.optJSONArray("materials")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                materials.add(
                    MaterialLine(
                        name = m.optString("name"),
                        quantity = m.optDouble("quantity", 0.0),
                        unit = m.optString("unit")
                    )
                )
            }
        }
        return DeliveryNote(
            id = obj.optString("id"),
            ownerUid = obj.optString("ownerUid"),
            supplierCompany = obj.optString("supplierCompany"),
            deliveryNoteNumber = obj.optString("deliveryNoteNumber"),
            deliveryNoteDate = obj.optString("deliveryNoteDate"),
            receivingCompany = obj.optString("receivingCompany"),
            siteArea = obj.optString("siteArea"),
            vehiclePlate = obj.optString("vehiclePlate"),
            rawOcrText = obj.optString("rawOcrText"),
            scannedQrPayload = obj.optString("scannedQrPayload").ifBlank { null },
            materials = materials
        )
    }
}
