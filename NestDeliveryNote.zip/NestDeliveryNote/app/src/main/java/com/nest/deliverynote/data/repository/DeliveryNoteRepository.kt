package com.nest.deliverynote.data.repository

import android.content.Context
import android.net.Uri
import com.nest.deliverynote.data.local.AppDatabase
import com.nest.deliverynote.data.local.PendingDraftEntity
import com.nest.deliverynote.data.model.DeliveryNote
import com.nest.deliverynote.data.model.RecordStatus
import com.nest.deliverynote.data.remote.FirestoreRepository
import com.nest.deliverynote.data.remote.StorageRepository
import com.nest.deliverynote.utils.NetworkMonitor
import kotlinx.coroutines.flow.Flow
import java.io.File

sealed class SaveOutcome {
    data class Saved(val noteId: String) : SaveOutcome()
    data class SavedAsPendingDraft(val localId: Long) : SaveOutcome()
    data class DuplicateDetected(val existing: DeliveryNote) : SaveOutcome()
    data class Failed(val message: String) : SaveOutcome()
}

/**
 * Orchestrates: duplicate detection -> (online) direct save to Firestore/Storage,
 * or (offline / failed) local pending-draft fallback that SyncWorker retries later.
 * There is deliberately no "assume success" path — every branch either confirms a
 * real server write or explicitly reports a local/pending/failed state to the UI.
 */
class DeliveryNoteRepository(private val context: Context) {

    private val firestoreRepo = FirestoreRepository()
    private val storageRepo = StorageRepository()
    private val db = AppDatabase.getInstance(context)

    fun observePendingDrafts(uid: String): Flow<List<PendingDraftEntity>> =
        db.pendingDraftDao().observeForUser(uid)

    suspend fun checkDuplicate(uid: String, note: DeliveryNote): DeliveryNote? {
        if (note.supplierCompany.isBlank() || note.deliveryNoteNumber.isBlank()) return null
        return firestoreRepo.findByDedupeKey(uid, note.supplierCompany, note.deliveryNoteNumber)
    }

    /**
     * [allowDuplicate] is set once the user has explicitly confirmed "save anyway"
     * on the duplicate warning dialog.
     */
    suspend fun save(uid: String, note: DeliveryNote, localPhotoUri: Uri?, allowDuplicate: Boolean = false): SaveOutcome {
        if (!allowDuplicate) {
            checkDuplicate(uid, note)?.let { existing ->
                return SaveOutcome.DuplicateDetected(existing)
            }
        }

        if (!NetworkMonitor.isOnline(context)) {
            return saveAsPendingDraft(uid, note, localPhotoUri)
        }

        return try {
            val noteId = if (note.id.isBlank()) java.util.UUID.randomUUID().toString() else note.id
            note.id = noteId
            note.status = RecordStatus.SAVED

            if (localPhotoUri != null) {
                val path = storageRepo.uploadPhoto(uid, localPhotoUri, noteId)
                note.photoStoragePath = path
            }

            val savedId = firestoreRepo.saveNote(uid, note)
            SaveOutcome.Saved(savedId)
        } catch (e: Exception) {
            // Network dropped mid-save, or the server rejected it — fall back to a
            // pending draft rather than silently losing the scan or lying about success.
            saveAsPendingDraft(uid, note, localPhotoUri, lastError = e.message)
        }
    }

    private suspend fun saveAsPendingDraft(uid: String, note: DeliveryNote, localPhotoUri: Uri?, lastError: String? = null): SaveOutcome {
        val localPhotoPath = localPhotoUri?.let { copyToPrivateStorage(it) } ?: ""
        note.status = RecordStatus.PENDING_UPLOAD
        val payload = DeliveryNoteJson.toJson(note).toString()
        val entity = PendingDraftEntity(
            ownerUid = uid,
            payloadJson = payload,
            localPhotoPath = localPhotoPath,
            createdAtEpochMs = System.currentTimeMillis(),
            lastError = lastError
        )
        val localId = db.pendingDraftDao().insert(entity)
        return SaveOutcome.SavedAsPendingDraft(localId)
    }

    private fun copyToPrivateStorage(source: Uri): String {
        val dir = File(context.filesDir, "pending_photos").apply { mkdirs() }
        val dest = File(dir, "${System.currentTimeMillis()}.jpg")
        context.contentResolver.openInputStream(source)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        }
        return dest.absolutePath
    }

    suspend fun listSavedNotes(uid: String): List<DeliveryNote> = firestoreRepo.listNotes(uid)

    suspend fun deleteNote(uid: String, note: DeliveryNote) {
        if (note.photoStoragePath.isNotBlank()) {
            storageRepo.deletePhoto(note.photoStoragePath)
        }
        firestoreRepo.deleteNote(uid, note.id)
    }
}
