package com.nest.deliverynote.ocr

import com.nest.deliverynote.data.model.MaterialLine

/**
 * Best-effort structured extraction from raw OCR text.
 *
 * IMPORTANT: every field here is a *guess*. The UI (ReviewScreen) must always show
 * these values to the user for confirmation/correction before anything is saved —
 * this parser must never be trusted to write directly to a saved record. Any field
 * the parser could not find with reasonable confidence is left blank (never invented).
 */
data class ParsedDeliveryNote(
    var supplierCompany: String? = null,
    var deliveryNoteNumber: String? = null,
    var deliveryNoteDate: String? = null, // yyyy-MM-dd if confidently parsed
    var receivingCompany: String? = null,
    var siteArea: String? = null,
    var vehiclePlate: String? = null,
    var materials: MutableList<MaterialLine> = mutableListOf()
)

/**
 * A pluggable per-supplier extraction strategy. Different suppliers use different
 * layouts, so new suppliers can be supported by adding a new [DeliveryNoteLayoutParser]
 * to [DeliveryNoteParserRegistry] without touching the generic fallback logic.
 */
interface DeliveryNoteLayoutParser {
    /** Quick check: does this raw OCR text look like it came from this supplier's layout? */
    fun matches(rawText: String): Boolean

    fun parse(rawText: String, qrPayload: String?): ParsedDeliveryNote
}

object DeliveryNoteParserRegistry {

    private val layoutParsers: List<DeliveryNoteLayoutParser> = listOf(
        CimkoConcreteParser()
    )

    private val fallback = GenericHeuristicParser()

    fun parse(rawText: String, qrPayload: String?): ParsedDeliveryNote {
        val matched = layoutParsers.firstOrNull { it.matches(rawText) }
        return matched?.parse(rawText, qrPayload) ?: fallback.parse(rawText, qrPayload)
    }
}

/** Turkish/generic regex helpers shared by parsers. */
internal object ParseUtils {

    private val datePatterns = listOf(
        Regex("""\b(\d{2})[./-](\d{2})[./-](\d{4})\b"""), // dd.MM.yyyy
        Regex("""\b(\d{4})[./-](\d{2})[./-](\d{2})\b"""), // yyyy-MM-dd
    )

    /** Returns yyyy-MM-dd, or null if no confident date match was found. */
    fun findDate(text: String): String? {
        for (pattern in datePatterns) {
            val m = pattern.find(text) ?: continue
            val g = m.groupValues
            return if (g[1].length == 4) {
                "${g[1]}-${g[2]}-${g[3]}"
            } else {
                "${g[3]}-${g[2]}-${g[1]}"
            }
        }
        return null
    }

    /** Turkish vehicle plate format, e.g. "34 ABC 123" / "34AB1234". */
    fun findPlate(text: String): String? {
        val pattern = Regex("""\b([0-8][0-9])\s?([A-PR-VYZ]{1,3})\s?(\d{2,4})\b""")
        return pattern.find(text)?.value?.trim()
    }

    fun findLabeledValue(text: String, labels: List<String>): String? {
        for (label in labels) {
            val pattern = Regex(
                """$label\s*[:\-]?\s*([^\n\r]{2,60})""",
                RegexOption.IGNORE_CASE
            )
            val match = pattern.find(text)
            val value = match?.groupValues?.get(1)?.trim()
            if (!value.isNullOrBlank()) return value
        }
        return null
    }

    fun findQuantityAndUnit(text: String): Pair<Double, String>? {
        val pattern = Regex(
            """(\d+[.,]?\d*)\s*(m3|m³|m2|m²|ton|kg|adet|mtül|lm)""",
            RegexOption.IGNORE_CASE
        )
        val match = pattern.find(text) ?: return null
        val amount = match.groupValues[1].replace(",", ".").toDoubleOrNull() ?: return null
        val unit = normalizeUnit(match.groupValues[2])
        return amount to unit
    }

    fun normalizeUnit(raw: String): String = when (raw.lowercase()) {
        "m3", "m³" -> "m³"
        "m2", "m²" -> "m²"
        "mtül", "lm" -> "mtül"
        "adet" -> "adet"
        "ton" -> "ton"
        "kg" -> "kg"
        else -> raw
    }
}

/**
 * Generic fallback: looks for common Turkish delivery-note ("İrsaliye") field labels.
 * Deliberately conservative — leaves a field null rather than guessing.
 */
class GenericHeuristicParser : DeliveryNoteLayoutParser {
    override fun matches(rawText: String): Boolean = true // always usable as a last resort

    override fun parse(rawText: String, qrPayload: String?): ParsedDeliveryNote {
        val result = ParsedDeliveryNote()
        result.deliveryNoteNumber = ParseUtils.findLabeledValue(
            rawText, listOf("İrsaliye No", "Irsaliye No", "Belge No", "Fiş No")
        )
        result.deliveryNoteDate = ParseUtils.findDate(rawText)
        result.supplierCompany = ParseUtils.findLabeledValue(
            rawText, listOf("Tedarikçi", "Tedarikci", "Satıcı", "Firma")
        )
        result.receivingCompany = ParseUtils.findLabeledValue(
            rawText, listOf("Alıcı", "Alici", "Teslim Alan", "Müşteri")
        )
        result.siteArea = ParseUtils.findLabeledValue(
            rawText, listOf("Şantiye", "Santiye", "Teslimat Yeri", "Şantiye Adı")
        )
        result.vehiclePlate = ParseUtils.findPlate(rawText)

        ParseUtils.findQuantityAndUnit(rawText)?.let { (qty, unit) ->
            val materialName = ParseUtils.findLabeledValue(
                rawText, listOf("Malzeme", "Ürün", "Cinsi")
            ) ?: ""
            result.materials.add(MaterialLine(name = materialName, quantity = qty, unit = unit))
        }
        return result
    }
}

/**
 * Layout-specific parser for ÇİMKO ready-mix concrete e-delivery notes.
 * These typically include the text "ÇİMKO", a concrete class (e.g. "C25/30" or
 * "BS20"), and a volume in m³.
 */
class CimkoConcreteParser : DeliveryNoteLayoutParser {
    override fun matches(rawText: String): Boolean =
        rawText.contains("ÇİMKO", ignoreCase = true) || rawText.contains("CIMKO", ignoreCase = true)

    override fun parse(rawText: String, qrPayload: String?): ParsedDeliveryNote {
        val result = ParsedDeliveryNote(supplierCompany = "ÇİMKO")

        result.deliveryNoteNumber = ParseUtils.findLabeledValue(
            rawText, listOf("İrsaliye No", "Sevk İrsaliye No", "Belge No")
        )
        result.deliveryNoteDate = ParseUtils.findDate(rawText)
        result.receivingCompany = ParseUtils.findLabeledValue(
            rawText, listOf("Alıcı", "Müşteri", "Şantiye Adı")
        )
        result.siteArea = ParseUtils.findLabeledValue(
            rawText, listOf("Şantiye", "Teslimat Yeri")
        )
        result.vehiclePlate = ParseUtils.findPlate(rawText)

        val concreteClass = Regex("""\b([BC]\s?\d{2}\s?/?\s?\d{0,2})\b""").find(rawText)?.value?.trim()
        val materialName = if (concreteClass != null) "Hazır Beton ($concreteClass)" else "Hazır Beton"

        ParseUtils.findQuantityAndUnit(rawText)?.let { (qty, unit) ->
            result.materials.add(MaterialLine(name = materialName, quantity = qty, unit = unit))
        } ?: run {
            // Volume found but without a matched unit keyword right next to it — still
            // don't guess a quantity; leave the material row for manual entry.
            result.materials.add(MaterialLine(name = materialName, quantity = 0.0, unit = "m³"))
        }

        return result
    }
}
