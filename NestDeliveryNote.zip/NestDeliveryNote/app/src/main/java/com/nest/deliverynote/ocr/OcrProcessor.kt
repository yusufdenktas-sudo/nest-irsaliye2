package com.nest.deliverynote.ocr

import android.graphics.Bitmap
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

/**
 * Wraps ML Kit's on-device Text Recognition (Latin script, which covers Turkish
 * characters: ç, ğ, ı, ö, ş, ü) and Barcode Scanning (for delivery-note QR codes).
 * Both models run fully on-device — no image data leaves the phone during OCR itself.
 */
class OcrProcessor {

    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val barcodeScanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE, Barcode.FORMAT_ALL_FORMATS)
            .build()
    )

    data class OcrResult(
        val rawText: String,
        val qrPayload: String?
    )

    suspend fun process(bitmap: Bitmap): OcrResult {
        val image = InputImage.fromBitmap(bitmap, 0)

        val textResult = textRecognizer.process(image).await()

        val qrPayload = try {
            val barcodes = barcodeScanner.process(image).await()
            barcodes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
        } catch (e: Exception) {
            null
        }

        return OcrResult(rawText = textResult.text, qrPayload = qrPayload)
    }
}
