package com.nest.deliverynote.sync

import android.content.Context
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.nest.deliverynote.data.local.AppDatabase
import com.nest.deliverynote.data.local.PendingDraftEntity
import com.nest.deliverynote.data.model.RecordStatus
import com.nest.deliverynote.data.remote.FirestoreRepository
import com.nest.deliverynote.data.remote.StorageRepository
import com.nest.deliverynote.data.repository.DeliveryNoteJson
import com.nest.deliverynote.utils.NetworkMonitor
import java.io.File

/**
 * Retries every locally-pending draft once connectivity returns. Scheduled as a
 * one-time expedited request from a network callback, AND as a periodic safety-net
 * (every ~15 min, WorkManager's minimum) in case the callback is missed (e.g. the
 * process was killed). A draft is only deleted from the local queue after Firestore
 * confirms the write — matching "no fake success" for the online path too.
 */
class SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    private val dao = AppDatabase.getInstance(context).pendingDraftDao()
    private val firestoreRepo = FirestoreRepository()
    private val storageRepo = StorageRepository()

    override suspend fun doWork(): Result {
        if (!NetworkMonitor.isOnline(applicationContext)) return Result.retry()

        val pending = dao.getAllPending()
        var anyFailure = false

        for (draft in pending) {
            try {
                uploadOne(draft)
                dao.delete(draft)
            } catch (e: Exception) {
                anyFailure = true
                dao.update(draft.copy(uploadAttempts = draft.uploadAttempts + 1, lastError = e.message))
            }
        }

        return if (anyFailure) Result.retry() else Result.success()
    }

    private suspend fun uploadOne(draft: PendingDraftEntity) {
        val note = DeliveryNoteJson.fromJson(draft.payloadJson)
        val noteId = note.id.ifBlank { java.util.UUID.randomUUID().toString() }
        note.id = noteId
        note.status = RecordStatus.SAVED

        if (draft.localPhotoPath.isNotBlank()) {
            val file = File(draft.localPhotoPath)
            if (file.exists()) {
                val path = storageRepo.uploadPhoto(draft.ownerUid, Uri.fromFile(file), noteId)
                note.photoStoragePath = path
                file.delete()
            }
        }

        firestoreRepo.saveNote(draft.ownerUid, note)
    }
}
