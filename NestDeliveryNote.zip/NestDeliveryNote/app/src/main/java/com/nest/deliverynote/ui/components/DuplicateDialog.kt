package com.nest.deliverynote.ui.components

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable

@Composable
fun DuplicateWarningDialog(onSaveAnyway: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Possible Duplicate") },
        text = { Text("A delivery note with this supplier and number already exists. Save anyway?") },
        confirmButton = { TextButton(onClick = onSaveAnyway) { Text("Save Anyway") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
