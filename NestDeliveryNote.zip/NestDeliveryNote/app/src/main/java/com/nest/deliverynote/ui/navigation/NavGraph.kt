package com.nest.deliverynote.ui.navigation

object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val SCAN = "scan"
    const val REVIEW = "review"
    const val RECORDS = "records"
    const val RECORD_DETAIL = "record_detail/{noteId}"
    const val SETTINGS = "settings"

    fun recordDetail(noteId: String) = "record_detail/$noteId"
}
