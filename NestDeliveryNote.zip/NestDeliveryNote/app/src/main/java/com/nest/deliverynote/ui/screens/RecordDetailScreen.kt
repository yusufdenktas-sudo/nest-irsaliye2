package com.nest.deliverynote.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.nest.deliverynote.data.model.DeliveryNote

@Composable
fun RecordDetailScreen(
    note: DeliveryNote,
    photoUrl: String?,
    onBack: () -> Unit,
    onDeleteRequested: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Delivery Note") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                },
                actions = {
                    IconButton(onClick = onDeleteRequested) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            if (photoUrl != null) {
                AsyncImage(model = photoUrl, contentDescription = null, modifier = Modifier.fillMaxWidth().height(220.dp))
                Spacer(Modifier.height(16.dp))
            }
            DetailRow("Supplier", note.supplierCompany)
            DetailRow("Delivery Note Number", note.deliveryNoteNumber)
            DetailRow("Date", note.deliveryNoteDate)
            DetailRow("Receiving Company", note.receivingCompany)
            DetailRow("Site Area", note.siteArea)
            DetailRow("Vehicle Plate", note.vehiclePlate)
            Spacer(Modifier.height(12.dp))
            Text("Materials", style = MaterialTheme.typography.titleLarge)
            note.materials.forEach { m ->
                Text("• ${m.name}: ${m.quantity} ${m.unit}")
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Text(value.ifBlank { "—" }, style = MaterialTheme.typography.bodyLarge)
    }
}
