package com.nest.deliverynote.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nest.deliverynote.data.model.DeliveryNote
import com.nest.deliverynote.data.model.RecordStatus

@Composable
fun RecordsListScreen(
    records: List<DeliveryNote>,
    isLoading: Boolean,
    onBack: () -> Unit,
    onOpenRecord: (DeliveryNote) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Records") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (records.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Text("No records yet. Scan your first delivery note.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(records) { note ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        tonalElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { onOpenRecord(note) }
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(note.supplierCompany.ifBlank { "(no supplier)" }, style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(4.dp))
                            Text("No: ${note.deliveryNoteNumber}  •  ${note.deliveryNoteDate}")
                            Text("${note.materials.size} material line(s)  •  ${statusLabel(note.status)}")
                        }
                    }
                }
            }
        }
    }
}

private fun statusLabel(status: RecordStatus): String = when (status) {
    RecordStatus.PENDING_UPLOAD -> "Pending upload"
    RecordStatus.UPLOADING -> "Uploading…"
    RecordStatus.SAVED -> "Saved"
    RecordStatus.REPORTED -> "Reported"
    RecordStatus.REPORT_FAILED -> "Report failed — will retry"
    RecordStatus.DELETED -> "Deleted"
}
