package com.nest.deliverynote.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nest.deliverynote.data.model.MaterialLine
import com.nest.deliverynote.utils.Validators

data class ReviewFormState(
    var supplierCompany: String,
    var deliveryNoteNumber: String,
    var deliveryNoteDate: String,
    var receivingCompany: String,
    var siteArea: String,
    var vehiclePlate: String,
    var materials: MutableList<MaterialLine>
)

/**
 * Every value here originated as an OCR guess but is fully editable — nothing is
 * saved until the user presses Save on THIS screen, satisfying "extracted data must
 * always be shown for review before saving" and "never guess silently".
 */
@Composable
fun ReviewScreen(
    initial: ReviewFormState,
    isSaving: Boolean,
    errorMessage: String?,
    onSave: (ReviewFormState) -> Unit,
    onCancel: () -> Unit
) {
    var supplier by remember { mutableStateOf(initial.supplierCompany) }
    var noteNumber by remember { mutableStateOf(initial.deliveryNoteNumber) }
    var date by remember { mutableStateOf(initial.deliveryNoteDate) }
    var receiving by remember { mutableStateOf(initial.receivingCompany) }
    var siteArea by remember { mutableStateOf(initial.siteArea) }
    var plate by remember { mutableStateOf(initial.vehiclePlate) }
    var materials by remember { mutableStateOf(initial.materials.toMutableList()) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Review Extracted Data") }) },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Row(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                        Text("Cancel")
                    }
                    Spacer(Modifier.width(12.dp))
                    Button(
                        onClick = {
                            onSave(
                                ReviewFormState(supplier, noteNumber, date, receiving, siteArea, plate, materials)
                            )
                        },
                        enabled = !isSaving,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Text("Save")
                        }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(Modifier.height(8.dp)) }
            item {
                OutlinedTextField(
                    value = supplier, onValueChange = { supplier = it },
                    label = { Text("Supplier Company") }, modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(
                    value = noteNumber, onValueChange = { noteNumber = it },
                    label = { Text("Delivery Note Number") }, modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(
                    value = date, onValueChange = { date = it },
                    label = { Text("Delivery Note Date (yyyy-MM-dd)") }, modifier = Modifier.fillMaxWidth(),
                    isError = date.isNotBlank() && !Validators.isValidDate(date),
                    supportingText = { Text("Example: 2026-09-12") }
                )
            }
            item {
                OutlinedTextField(
                    value = receiving, onValueChange = { receiving = it },
                    label = { Text("Receiving Company") }, modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(
                    value = siteArea, onValueChange = { siteArea = it },
                    label = { Text("Delivery Location / Site Area") }, modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                OutlinedTextField(
                    value = plate, onValueChange = { plate = it },
                    label = { Text("Vehicle License Plate") }, modifier = Modifier.fillMaxWidth(),
                    isError = !Validators.isValidPlate(plate)
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Materials", style = MaterialTheme.typography.titleLarge)
                    IconButton(onClick = { materials = (materials + MaterialLine()).toMutableList() }) {
                        Icon(Icons.Filled.Add, contentDescription = "Add Material")
                    }
                }
            }

            items(materials.size) { index ->
                MaterialRow(
                    line = materials[index],
                    onChange = { updated ->
                        materials = materials.toMutableList().also { it[index] = updated }
                    },
                    onDelete = {
                        materials = materials.toMutableList().also { it.removeAt(index) }
                    }
                )
            }

            if (errorMessage != null) {
                item {
                    Text(errorMessage, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun MaterialRow(line: MaterialLine, onChange: (MaterialLine) -> Unit, onDelete: () -> Unit) {
    Surface(shape = RoundedCornerShape(12.dp), tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row {
                OutlinedTextField(
                    value = line.name,
                    onValueChange = { onChange(line.copy(name = it)) },
                    label = { Text("Material") },
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Remove")
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = if (line.quantity == 0.0) "" else line.quantity.toString(),
                    onValueChange = { text ->
                        val v = text.replace(",", ".").toDoubleOrNull() ?: 0.0
                        onChange(line.copy(quantity = v))
                    },
                    label = { Text("Quantity") },
                    modifier = Modifier.weight(1f)
                )
                var expanded by remember { mutableStateOf(false) }
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = line.unit,
                        onValueChange = { onChange(line.copy(unit = it)) },
                        label = { Text("Unit") },
                        trailingIcon = {
                            IconButton(onClick = { expanded = true }) {
                                Icon(Icons.Filled.Add, contentDescription = null)
                            }
                        }
                    )
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        Validators.allowedUnits.forEach { unit ->
                            DropdownMenuItem(text = { Text(unit) }, onClick = {
                                onChange(line.copy(unit = unit))
                                expanded = false
                            })
                        }
                    }
                }
            }
        }
    }
}
