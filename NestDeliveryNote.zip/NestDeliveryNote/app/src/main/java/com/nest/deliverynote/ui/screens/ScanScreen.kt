package com.nest.deliverynote.ui.screens

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun ScanScreen(
    imageUri: Uri?,
    isProcessing: Boolean,
    errorMessage: String?,
    onTakePhoto: () -> Unit,
    onPickGallery: () -> Unit,
    onProcess: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Scan Delivery Note") }) }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (imageUri != null) {
                AsyncImage(
                    model = imageUri,
                    contentDescription = "Captured delivery note",
                    modifier = Modifier.fillMaxWidth().height(320.dp)
                )
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = onProcess,
                    enabled = !isProcessing,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Reading text…")
                    } else {
                        Text("Extract Data")
                    }
                }
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onBack, enabled = !isProcessing) { Text("Retake") }
            } else {
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = onTakePhoto,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(64.dp)
                ) {
                    Icon(Icons.Filled.CameraAlt, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Take Photo")
                }
                Spacer(Modifier.height(16.dp))
                OutlinedButton(
                    onClick = onPickGallery,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(64.dp)
                ) {
                    Icon(Icons.Filled.Image, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Choose from Gallery")
                }
                Spacer(Modifier.weight(1f))
            }

            if (errorMessage != null) {
                Spacer(Modifier.height(16.dp))
                Text(errorMessage, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
