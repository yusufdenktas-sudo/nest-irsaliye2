package com.nest.deliverynote.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nest.deliverynote.data.model.ReportSettings
import com.nest.deliverynote.utils.Validators

@Composable
fun SettingsScreen(
    initial: ReportSettings,
    isSaving: Boolean,
    savedMessage: String?,
    onBack: () -> Unit,
    onSave: (ReportSettings) -> Unit
) {
    var email by remember { mutableStateOf(initial.recipientEmail) }
    var hour by remember { mutableStateOf(initial.sendHour.toString()) }
    var minute by remember { mutableStateOf(initial.sendMinute.toString()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            Text("Daily Excel Report", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Recipient email") },
                isError = email.isNotBlank() && !Validators.isValidEmail(email),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = hour, onValueChange = { hour = it.filter { c -> c.isDigit() } },
                    label = { Text("Hour (0-23)") }, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = minute, onValueChange = { minute = it.filter { c -> c.isDigit() } },
                    label = { Text("Minute (0-59)") }, modifier = Modifier.weight(1f)
                )
            }
            Text(
                "Time zone: Europe/Istanbul",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 8.dp)
            )
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    onSave(
                        ReportSettings(
                            recipientEmail = email.trim(),
                            sendHour = hour.toIntOrNull()?.coerceIn(0, 23) ?: 0,
                            sendMinute = minute.toIntOrNull()?.coerceIn(0, 59) ?: 0
                        )
                    )
                },
                enabled = !isSaving && Validators.isValidEmail(email),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isSaving) "Saving…" else "Save")
            }
            if (savedMessage != null) {
                Spacer(Modifier.height(12.dp))
                Text(savedMessage)
            }
        }
    }
}
