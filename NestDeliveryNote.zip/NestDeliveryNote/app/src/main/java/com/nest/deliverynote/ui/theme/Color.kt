package com.nest.deliverynote.ui.theme

import androidx.compose.ui.graphics.Color

val NestPrimary = Color(0xFF2E7D5B)
val NestPrimaryDark = Color(0xFF1F5C41)
val NestSecondary = Color(0xFF8CC9A8)
val NestBackground = Color(0xFFF7FAF8)
val NestSurface = Color(0xFFFFFFFF)
val NestError = Color(0xFFC0392B)
val NestOnPrimary = Color(0xFFFFFFFF)
val NestTextPrimary = Color(0xFF1B2B22)
