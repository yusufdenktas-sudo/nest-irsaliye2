package com.nest.deliverynote.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = NestPrimary,
    onPrimary = NestOnPrimary,
    primaryContainer = NestSecondary,
    background = NestBackground,
    surface = NestSurface,
    error = NestError,
    onBackground = NestTextPrimary,
    onSurface = NestTextPrimary
)

private val DarkColors = darkColorScheme(
    primary = NestSecondary,
    onPrimary = NestPrimaryDark,
    background = Color(0xFF10201A),
    surface = Color(0xFF16261F)
)

@Composable
fun NestDeliveryNoteTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = NestTypography,
        content = content
    )
}
