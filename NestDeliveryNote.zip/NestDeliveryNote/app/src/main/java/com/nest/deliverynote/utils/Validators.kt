package com.nest.deliverynote.utils

import android.util.Patterns
import java.text.SimpleDateFormat
import java.util.Locale

object Validators {

    fun isValidEmail(email: String): Boolean =
        email.isNotBlank() && Patterns.EMAIL_ADDRESS.matcher(email).matches()

    fun isValidDate(dateIso: String): Boolean {
        if (dateIso.isBlank()) return false
        return try {
            val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            fmt.isLenient = false
            fmt.parse(dateIso) != null
        } catch (e: Exception) {
            false
        }
    }

    fun isValidQuantity(quantity: Double): Boolean = quantity > 0.0 && quantity.isFinite()

    val allowedUnits = listOf("m³", "m²", "mtül", "adet", "ton", "kg")

    fun isValidUnit(unit: String): Boolean = unit.isNotBlank()

    fun isValidPlate(plate: String): Boolean =
        plate.isBlank() || Regex("""^[0-9]{2}\s?[A-Za-zÇĞİÖŞÜçğıöşü]{1,3}\s?[0-9]{2,4}$""").matches(plate.trim())

    /** A record is submittable once every required field is present and well-formed. */
    fun validateForSave(
        supplierCompany: String,
        deliveryNoteNumber: String,
        deliveryNoteDate: String,
        receivingCompany: String,
        materials: List<Pair<Double, String>>
    ): List<String> {
        val errors = mutableListOf<String>()
        if (supplierCompany.isBlank()) errors += "Supplier company is required."
        if (deliveryNoteNumber.isBlank()) errors += "Delivery note number is required."
        if (!isValidDate(deliveryNoteDate)) errors += "Delivery note date is missing or invalid."
        if (receivingCompany.isBlank()) errors += "Receiving company is required."
        if (materials.isEmpty()) errors += "At least one material line is required."
        materials.forEachIndexed { index, (qty, unit) ->
            if (!isValidQuantity(qty)) errors += "Material row ${index + 1}: quantity must be greater than zero."
            if (!isValidUnit(unit)) errors += "Material row ${index + 1}: unit is required."
        }
        return errors
    }
}
