# Nest Delivery Note — Setup Guide

This document covers everything that requires a real Firebase project, a real
Google Cloud OAuth configuration, or real SMTP credentials — none of which can
be created or verified inside this repository. Everything else in the project
is complete and buildable as-is.

## 1. Technology chosen, and why

- **Kotlin + Jetpack Compose (native Android)** — chosen over Flutter because the
  two OCR/QR building blocks specified (Google ML Kit Text Recognition and Barcode
  Scanning) are first-class, actively-maintained native Android SDKs with the most
  mature CameraX + Compose integration, and Firebase Auth/Firestore/Storage SDKs
  are also native-first. This avoids a Flutter plugin bridge for the single most
  important feature of the app (OCR accuracy).
- **Firebase (Auth, Firestore, Storage, Cloud Functions)** — a single vendor
  covers Google Sign-In, per-user data isolation via security rules, photo
  storage, and server-side scheduled jobs, which matches "daily report sent even
  if the phone is off" without running any separate backend server.
- **Room** — a small local SQLite cache used only to queue offline drafts
  (delivery notes scanned with no connection). It is not a general offline cache
  of server data.
- **WorkManager** — retries queued drafts automatically once connectivity
  returns, and as a periodic safety net.
- **ExcelJS + Nodemailer (Cloud Functions, Node.js/TypeScript)** — generates the
  XLSX report server-side (UTF-8 native, so Turkish characters are unaffected)
  and emails it via SMTP without ever putting credentials in the APK.

## 2. Project folder structure

```
NestDeliveryNote/
├── app/                          Android app module (Kotlin, Jetpack Compose)
│   └── src/main/java/com/nest/deliverynote/
│       ├── auth/                 Google Sign-In -> Firebase Auth bridge
│       ├── data/
│       │   ├── model/            DeliveryNote, MaterialLine, ReportSettings
│       │   ├── local/            Room DB for offline pending drafts
│       │   ├── remote/           Firestore + Storage repositories
│       │   └── repository/       Save/duplicate-check orchestration
│       ├── ocr/                  ML Kit text/QR processing + field extraction
│       ├── sync/                 WorkManager job to upload pending drafts
│       └── ui/                   Compose screens, navigation, theme
├── functions/                    Firebase Cloud Functions (Node/TypeScript)
│   └── src/index.ts              Scheduled Excel report + email delivery
├── firestore.rules, storage.rules, firestore.indexes.json
├── firebase.json
└── .github/workflows/android-build.yml   CI: builds a debug APK
```

## 3. Firebase services and configuration required

You need a real Firebase project (Blaze/pay-as-you-go plan — required for Cloud
Functions with outbound network access to an SMTP server):

1. Create a project at https://console.firebase.google.com.
2. **Authentication** → Sign-in method → enable **Google**.
3. **Firestore Database** → create in production mode, any region close to Turkey
   (e.g. `europe-west1`). Deploy `firestore.rules` and `firestore.indexes.json`.
4. **Storage** → create a default bucket. Deploy `storage.rules`.
5. **Functions** → upgrade to Blaze, then `firebase deploy --only functions`
   from inside `functions/` (after `npm install`).
6. Add an Android app to the project with package name **`com.nest.deliverynote`**,
   download the real `google-services.json`, and place it at `app/google-services.json`
   (a template describing the expected shape is at `app/google-services.json.example`).

## 4. Required Google OAuth settings

Firebase's "Google" sign-in provider auto-creates an OAuth client, but two things
need manual attention:

- **SHA-1 / SHA-256 certificate fingerprints**: add the debug keystore's SHA-1
  (`keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey
  -storepass android -keypass android`) and your release keystore's SHA-1/SHA-256
  under Project Settings → Your apps → the Android app, or Google Sign-In will
  fail with `DEVELOPER_ERROR` on real devices.
- **OAuth consent screen**: under Google Cloud Console → APIs & Services → OAuth
  consent screen, set the app to "Internal" if this is only for your organization's
  Google Workspace accounts (matches "restrict access to authorized Google
  accounts when necessary"), or "External" + verified if outside staff need it too.

`google-services.json` already contains the Web client ID Firebase generates;
`GoogleAuthManager.kt` reads it automatically via the generated
`R.string.default_web_client_id` resource, so no manual OAuth client ID needs to
be pasted into source code.

## 5. Required environment variables / secrets

None of these are stored in the APK or committed to git:

| Secret | Where it lives | Purpose |
|---|---|---|
| `app/google-services.json` | Local file, git-ignored | Firebase project config for the Android app |
| `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` | Cloud Functions secrets (`firebase functions:secrets:set SMTP_HOST` etc.) | Sending the daily report email |
| `GOOGLE_SERVICES_JSON_BASE64` | GitHub Actions repository secret | Lets CI reconstruct `google-services.json` at build time (`base64 -w0 app/google-services.json`) |
| Release signing keystore + passwords | Your own secure storage / GitHub Actions secrets, not included here | Signing a release (not debug) APK |

Set the SMTP secrets once with, e.g.:
```
firebase functions:secrets:set SMTP_HOST
firebase functions:secrets:set SMTP_PORT
firebase functions:secrets:set SMTP_USER
firebase functions:secrets:set SMTP_PASS
firebase functions:secrets:set SMTP_FROM
```

## 6. APK build process

**Locally (Android Studio):**
1. Place the real `app/google-services.json`.
2. Open the project root in Android Studio (Koala+ recommended), let Gradle sync.
3. Run on a device/emulator, or Build → Build Bundle(s)/APK(s) → Build APK(s).

**Command line:**
```
./gradlew assembleDebug   # after copying local.properties.example -> local.properties
```
(A Gradle wrapper jar is not checked into this repo to keep it lean — run
`gradle wrapper` once with any local Gradle 8.7 install to generate
`gradle/wrapper/gradle-wrapper.jar`, or just use your local `gradle` binary /
Android Studio's bundled Gradle, both of which read the existing
`gradle-wrapper.properties`.)

**GitHub Actions:** `.github/workflows/android-build.yml` builds a debug APK on
every push to `main` (or manually via "Run workflow"), using the
`GOOGLE_SERVICES_JSON_BASE64` secret, and uploads the APK as a build artifact.
It does not build or sign a release APK — that needs your release keystore,
deliberately kept out of this repo.

## 7. Features that cannot be fully tested without real credentials/hardware

- **Google Sign-In** — needs a real Firebase project + OAuth client + SHA-1
  fingerprint; cannot be exercised without them.
- **OCR accuracy on real delivery notes** — ML Kit runs on-device, but layout
  parsers (`CimkoConcreteParser`, `GenericHeuristicParser`) were written against
  the field labels described in the spec, not against an actual scanned ÇİMKO
  note image, so expect to tune the regexes once you test with real photos.
- **Firestore/Storage read/write and security rules** — need a deployed Firebase
  project; the rules in `firestore.rules`/`storage.rules` are written to the spec
  ("users only access their own records") but must be tested against real auth
  tokens (`firebase emulators:start` is the fastest way, or a real device).
- **Duplicate detection query** — depends on a populated Firestore index; the
  composite index is declared in `firestore.indexes.json` but Firestore will only
  finish building it after first deploy.
- **Camera capture** — needs a physical device or an emulator with a working
  camera; the emulator's simulated camera feed is not representative of real
  delivery-note photo quality/OCR results.
- **Daily scheduled email report** — needs a Blaze-plan Firebase project, real
  SMTP credentials, and either waiting for the schedule or calling the
  `triggerReportNow` callable function manually.
- **GitHub Actions APK build** — needs the `GOOGLE_SERVICES_JSON_BASE64` repo
  secret to be set, or the build will fail at the "Write google-services.json"
  step (by design — it must not silently build with a fake config).
