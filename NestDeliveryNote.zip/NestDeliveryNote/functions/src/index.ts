/**
 * Nest Delivery Note — Cloud Functions
 *
 * 1. dailyReportDispatcher: runs every 5 minutes, checks every user's configured
 *    report time (default 00:00 Europe/Istanbul) and, when it's that user's turn,
 *    builds an XLSX of their un-reported delivery notes (one row per material) and
 *    emails it. Runs entirely server-side, so the report goes out even if the
 *    phone is off.
 * 2. triggerReportNow: an authenticated callable so a signed-in user can request
 *    their own report immediately, for testing.
 *
 * SMTP credentials are read from Cloud Functions secrets (see docs/SETUP.md) —
 * never hard-coded and never bundled into the APK.
 */

import * as admin from "firebase-admin";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { onCall, HttpsError } from "firebase-functions/v2/https";
import { defineSecret } from "firebase-functions/params";
import * as logger from "firebase-functions/logger";
import ExcelJS from "exceljs";
import nodemailer from "nodemailer";

admin.initializeApp();
const db = admin.firestore();

const SMTP_HOST = defineSecret("SMTP_HOST");
const SMTP_PORT = defineSecret("SMTP_PORT");
const SMTP_USER = defineSecret("SMTP_USER");
const SMTP_PASS = defineSecret("SMTP_PASS");
const SMTP_FROM = defineSecret("SMTP_FROM");

const REPORT_WINDOW_MINUTES = 5; // must match the schedule interval below

interface MaterialLine {
  name: string;
  quantity: number;
  unit: string;
}

interface DeliveryNoteDoc {
  supplierCompany: string;
  deliveryNoteNumber: string;
  deliveryNoteDate: string;
  receivingCompany: string;
  siteArea: string;
  vehiclePlate: string;
  materials: MaterialLine[];
  photoStoragePath: string;
  status: string;
}

interface ReportSettingsDoc {
  recipientEmail: string;
  sendHour: number;
  sendMinute: number;
  timezone: string;
}

function istanbulNow(): { hour: number; minute: number; dateStr: string } {
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/Istanbul",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  const parts = Object.fromEntries(fmt.formatToParts(new Date()).map((p) => [p.type, p.value]));
  return {
    hour: parseInt(parts.hour, 10),
    minute: parseInt(parts.minute, 10),
    dateStr: `${parts.year}-${parts.month}-${parts.day}`,
  };
}

function isWithinWindow(nowHour: number, nowMinute: number, targetHour: number, targetMinute: number): boolean {
  const nowTotal = nowHour * 60 + nowMinute;
  const targetTotal = targetHour * 60 + targetMinute;
  const diff = ((nowTotal - targetTotal) + 1440) % 1440;
  return diff < REPORT_WINDOW_MINUTES;
}

async function buildWorkbook(uid: string, notes: (DeliveryNoteDoc & { id: string })[]): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Nest Delivery Note";
  const sheet = workbook.addWorksheet("Delivery Notes", {
    properties: { defaultColWidth: 18 },
  });

  sheet.columns = [
    { header: "Date", key: "date" },
    { header: "Delivery Note Number", key: "noteNumber" },
    { header: "Supplier", key: "supplier" },
    { header: "Receiving Company", key: "receivingCompany" },
    { header: "Site Area", key: "siteArea" },
    { header: "Vehicle Plate", key: "vehiclePlate" },
    { header: "Material", key: "material" },
    { header: "Quantity", key: "quantity" },
    { header: "Unit", key: "unit" },
    { header: "Photo / Record Reference", key: "recordRef" },
  ];
  sheet.getRow(1).font = { bold: true };

  for (const note of notes) {
    const materials = note.materials.length > 0 ? note.materials : [{ name: "", quantity: 0, unit: "" }];
    for (const material of materials) {
      sheet.addRow({
        date: note.deliveryNoteDate,
        noteNumber: note.deliveryNoteNumber,
        supplier: note.supplierCompany,
        receivingCompany: note.receivingCompany,
        siteArea: note.siteArea,
        vehiclePlate: note.vehiclePlate,
        material: material.name,
        quantity: material.quantity,
        unit: material.unit,
        recordRef: note.id,
      });
    }
  }

  // Excel/ExcelJS write UTF-8 internally, so Turkish characters (ç ğ ı ö ş ü) round-trip correctly.
  const arrayBuffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(arrayBuffer);
}

function buildTransport() {
  return nodemailer.createTransport({
    host: SMTP_HOST.value(),
    port: parseInt(SMTP_PORT.value() || "587", 10),
    secure: parseInt(SMTP_PORT.value() || "587", 10) === 465,
    auth: {
      user: SMTP_USER.value(),
      pass: SMTP_PASS.value(),
    },
  });
}

/**
 * Attempts one user's daily report. Idempotent per (uid, dateStr):
 *  - a run already marked "sent" is never retried (no duplicate emails)
 *  - a run marked "uncertain" (SMTP response was ambiguous, e.g. a timeout) is
 *    left for manual review rather than auto-retried, since we can't be sure the
 *    first email didn't already go out
 *  - a run marked "failed" (clear rejection, e.g. auth error) is safe to retry
 */
async function attemptSendReport(uid: string, dateStr: string): Promise<void> {
  const runRef = db.collection("reportRuns").doc(`${uid}_${dateStr}`);

  const shouldProceed = await db.runTransaction(async (tx) => {
    const runDoc = await tx.get(runRef);
    if (runDoc.exists) {
      const status = runDoc.data()?.status;
      if (status === "sent" || status === "uncertain") {
        return false; // do not touch again automatically
      }
    }
    tx.set(runRef, { uid, dateStr, status: "sending", updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    return true;
  });

  if (!shouldProceed) {
    logger.info(`Skipping report for ${uid} on ${dateStr}: already sent or awaiting manual review.`);
    return;
  }

  try {
    const settingsSnap = await db.collection("users").doc(uid).collection("settings").doc("report").get();
    const settings: ReportSettingsDoc = settingsSnap.exists
      ? (settingsSnap.data() as ReportSettingsDoc)
      : { recipientEmail: "yusufdenktas@nestpeyzaj.com", sendHour: 0, sendMinute: 0, timezone: "Europe/Istanbul" };

    const notesSnap = await db
      .collection("users").doc(uid).collection("deliveryNotes")
      .where("status", "==", "SAVED")
      .get();

    const notes = notesSnap.docs.map((d) => ({ id: d.id, ...(d.data() as DeliveryNoteDoc) }));

    if (notes.length === 0) {
      await runRef.set({ status: "sent", noteCount: 0, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
      logger.info(`No pending delivery notes for ${uid} on ${dateStr}; nothing to send.`);
      return;
    }

    const buffer = await buildWorkbook(uid, notes);
    const transport = buildTransport();

    const info = await transport.sendMail({
      from: SMTP_FROM.value(),
      to: settings.recipientEmail,
      subject: `Nest Delivery Note — Daily Report — ${dateStr}`,
      text: `Attached is the daily delivery note report for ${dateStr} (${notes.length} record(s)).`,
      attachments: [
        {
          filename: `delivery-notes-${dateStr}.xlsx`,
          content: buffer,
          contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        },
      ],
    });

    // nodemailer resolves with `accepted`/`rejected` arrays once the SMTP server
    // has ACKed the message; treat anything else (thrown timeout, no ack) below
    // as "uncertain" rather than assuming success.
    const accepted = info.accepted && info.accepted.length > 0;
    if (!accepted) {
      await runRef.set({ status: "failed", error: "SMTP server rejected the message", updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
      await markNotes(notes.map((n) => n.id), uid, "REPORT_FAILED");
      return;
    }

    const batch = db.batch();
    for (const note of notes) {
      const ref = db.collection("users").doc(uid).collection("deliveryNotes").doc(note.id);
      batch.update(ref, {
        status: "REPORTED",
        reportedAt: admin.firestore.FieldValue.serverTimestamp(),
        reportBatchId: runRef.id,
      });
    }
    await batch.commit();

    await runRef.set(
      { status: "sent", noteCount: notes.length, updatedAt: admin.firestore.FieldValue.serverTimestamp() },
      { merge: true }
    );
    logger.info(`Sent report for ${uid} on ${dateStr}: ${notes.length} record(s).`);
  } catch (err) {
    // Network/timeout/unknown errors: we genuinely don't know if the email went
    // out, so mark "uncertain" and stop touching it automatically.
    logger.error(`Uncertain outcome sending report for ${uid} on ${dateStr}`, err);
    await runRef.set(
      { status: "uncertain", error: String(err), updatedAt: admin.firestore.FieldValue.serverTimestamp() },
      { merge: true }
    );
  }
}

async function markNotes(noteIds: string[], uid: string, status: string): Promise<void> {
  const batch = db.batch();
  for (const id of noteIds) {
    batch.update(db.collection("users").doc(uid).collection("deliveryNotes").doc(id), { status });
  }
  await batch.commit();
}

export const dailyReportDispatcher = onSchedule(
  {
    schedule: `every ${REPORT_WINDOW_MINUTES} minutes`,
    timeZone: "Europe/Istanbul",
    secrets: [SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM],
  },
  async () => {
    const { hour, minute, dateStr } = istanbulNow();

    const usersSnap = await db.collection("users").get();
    for (const userDoc of usersSnap.docs) {
      const uid = userDoc.id;
      const settingsSnap = await db.collection("users").doc(uid).collection("settings").doc("report").get();
      const settings: ReportSettingsDoc = settingsSnap.exists
        ? (settingsSnap.data() as ReportSettingsDoc)
        : { recipientEmail: "yusufdenktas@nestpeyzaj.com", sendHour: 0, sendMinute: 0, timezone: "Europe/Istanbul" };

      if (isWithinWindow(hour, minute, settings.sendHour, settings.sendMinute)) {
        await attemptSendReport(uid, dateStr);
      }
    }
  }
);

export const triggerReportNow = onCall(
  { secrets: [SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM] },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "Sign in required.");
    }
    const { dateStr } = istanbulNow();
    await attemptSendReport(request.auth.uid, dateStr);
    return { ok: true };
  }
);
